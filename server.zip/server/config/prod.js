module.exports={
    MONGOURI: process.env.MOGOURI,  // we reate this url or env variable on heroku(here) and paste url in env variable
    JWT_SECRET:"process.env.JWT_SEC",
    SENDGRID_API:process.env.SENDGRID_API,
    EMAIL:process.env.EMAIL
}
// good prac to create env varibale for sensitive data