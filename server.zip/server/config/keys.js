// module.exports={
//     MONGOURI:"mongodb+srv://husain:imopnrZcgo6UFafg@cluster0.z1rlkr9.mongodb.net/?retryWrites=true&w=majority",
//     JWT_SECRET:"husainbengali"
// }

if(process.env.NODE_ENV==='production'){
    module.exports = require('./prod')
}else{
    module.exports = require('./dev')
}