module.exports={
    MONGOURI:"mongodb+srv://husain:imopnrZcgo6UFafg@cluster0.z1rlkr9.mongodb.net/?retryWrites=true&w=majority",
    JWT_SECRET:"husainbengali",
    SENDGRID_API:"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",
    EMAIL:"http://localhost:3000"
}
//