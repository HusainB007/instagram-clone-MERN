import React,{useEffect,createContext,useReducer,useContext} from 'react';
import NavBar from './components/Navbar'
import "./App.css"
import {BrowserRouter as Router,Route,Navigate,useNavigate,Routes,Switch} from 'react-router-dom'
import Home from './components/screens/Home'
import Signin from './components/screens/SignIn'
import Profile from './components/screens/Profile'
import Signup from './components/screens/Signup'
import CreatePost from './components/screens/CreatePost'
import SubscribedUserPosts from './components/screens/SubscribesUserPosts'
import UserProfile from './components/screens/UserProfile'
import Reset from './components/screens/Reset'

import NewPassword from './components/screens/Newpassword'
import {reducer,initialState} from './reducers/userReducer'
export const UserContext = createContext()

const Routing = ()=>{
  const navigate = useNavigate()
  
  const {state,dispatch} = useContext(UserContext)  // call dispatch to update state with user data
  //make user data available in state because if user exits without logout then if he comes back state should be there
  useEffect(()=>{
    const user = JSON.parse(localStorage.getItem("user"))
    if(user){
      dispatch({type:"USER",payload:user})
      navigate('/')  // added extra
    }else{
      if(!window.location.pathname.startsWith('/reset'))
           navigate('/signin')
    }
  },[])
  return(
    <>
 
  <Routes> 

<Route exact path="/" element={<Home />} />
<Route exact path="/signin" element={<Signin />} />
<Route exact path="/signup" element={<Signup />} />
<Route exact path="/profile" element={<Profile />} />
<Route exact path="/create" element={<CreatePost />} />
<Route exact path='/profile/:userid' element={<UserProfile />} />
<Route exact path='/myfollowingpost' element={<SubscribedUserPosts  />} />
<Route exact path='/reset' element={<Reset  />} />
<Route exact path='/reset/:token' element={<NewPassword  />} />
    
    
   
     </Routes>  

    </>
  )
}

// function App() {

//   const [state,dispatch] = useReducer(reducer,initialState) 

  function App() {
    const [state,dispatch] = useReducer(reducer,initialState) // userreducer return 2 elements dis[ath is for central state and state for 1st]
    return (
      <UserContext.Provider value={{state,dispatch}}>
      <Router>
        <NavBar />
        <Routing />
        
      </Router>
      </UserContext.Provider>
    );
  }

//   return (
//  <Router>
//   <NavBar />
//   <Routes> 

//   <Route exact path="/" element={<Home />} />
//   <Route exact path="/signin" element={<Signin />} />
//   <Route exact path="/signup" element={<Signup />} />
//   <Route exact path="/profile" element={<Profile />} />
//   <Route exact path="/create" element={<CreatePost />} />
      
     
//       </Routes>  
//       </Router>
//   );
// }

export default App;
